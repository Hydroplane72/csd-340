Topic 70 - Laughter Bonds People Together
	Visualization
	I specifically chose this topic because the name reminded me of Fluffy the comedian and a story about making cops laugh to get out of a ticket. I couldn't help myself and just had to bring it up for this topic. To bring it all together and relate it to this topic, Fluffy mentions that getting a cop to laugh increases your chances of getting out of a ticket.

Making Cops Laugh. (2026). Youtube. https://youtu.be/a77Dw3tNv8o?t=26

	Visualization/Embellishment
	My visualization/Embellishment is about an article I found on how to be a good employee at after-work events. The main reason I give this is that if any of you get into the corporate world and get invited to an after-work party. It is a good idea to know some etiquette for talking with coworkers outside of work time.
https://www.jobadvisor.link/2025/05/navigating-happy-hour-drinks-and.html


Topic 74 - Stories and Anecdotes Persuade more than Data Alone
	Embellishment
	One of the reasons I chose this topic was its brevity. That allows me to embellish more on this topic than usual.
	I see this topic used all the time at my work. While we do use numbers quite often. Most of the time, when trying to get a point across, we do it in a story format. For instance, I have an intense dislike for NServiceBus. I could go over the 100's of hours I have wasted debugging and generally trying to maintain any codebase that uses NServiceBus. Instead, I would rather talk about the story of me spending 90% of my time in January and February trying to make just a couple of line changes to a single NSB Endpoint. If this process had been a REST API or even a Console-driven app, I could guarantee that this project would have been done within a week. At this point, the project has dragged on for nearly 3 months because NSB is very finicky, and even updating a single package reference can cause the entire program to stop running, and you have very little in the way of logs to tell you why.

Visualization
	I found this video about this guy teaching this topic in a short story format. I really liked it because he taught about learning in a story format, telling it as a story. He really hit the nail on the head compared to the topic of the book.
	https://www.youtube.com/shorts/gUqaEwm_6GY?feature=share