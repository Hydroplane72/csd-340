Topic #61 - People are motivated to compete when there are fewer Competitors

Embellishment
	To add on to the reading in the book. When competing in anything, it is always about perception and not just the number of people you are competing against. For instance, I played Battlefield 6 for a while. In the beginning, it was a lot of fun, and I was very motivated to keep playing and get better. As time has gone on, the issue has come up that I actually have a life outside of that game, and some people do not. This perception difference between me and "others who need to touch grass" is what has caused me to stop playing that game. I kept on getting put on matches where 2 or 3 people would dominate on each team, and the rest of the 20-30 of us were just cannon fodder, trying to do something. Admittedly, this is an issue that all multiplayer games struggle with.

Visualization:

	The video I found is actually about competition in people's lives. The person talks about how there are both healthy and unhealthy ways to view and live with competition. A good point brought up is that healthy competition is about the journey, not solely about the final goal.

https://www.youtube.com/watch?v=8O-O-V1AN5I

Topic #62 - People are Motivated by Autonomy

Embelishment

	I chose this topic because I really like to be independent. The number of times I have intentionally gone out of my way to avoid having to talk to someone is actually impressive to some. For instance, I would prefer to go into a restaurant and order food from the table on my phone, rather than ordering at a counter and feeling pressured to go as fast as possible.

Visualization

I chose this video mainly because the book mentioned it, and I couldn't help but look for something about the self-checkouts in stores. I love them and think they should stay around forever. I also recognize that some (mainly of the older generation) prefer to talk to someone. I also like having a cashier line option for those types of people, because talkers generally take longer (in my mind) than the grab-and-go type of person I am.

https://www.youtube.com/watch?v=vg6ngX7LtJs